#include "DandDCharacter.h"

void GenerateCharacter(Character * pCharacter)
{
}

void DisplayCharacter(Character * pCharacter)
{
}

void SaveCharacter(Character * pCharacter)
{
}

void LoadCharacter(Character * pCharacter, char * filename)
{
}

int DisplayMenu()
{
    int selection=(-1);

    return selection;
}